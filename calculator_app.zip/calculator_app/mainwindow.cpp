#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Connect digit buttons (0-9 and .)
    QList<QPushButton*> digitButtons = {
        ui->pushButton,    // 4
        ui->pushButton_2,  // 7
        ui->pushButton_3,  // 5
        ui->pushButton_4,  // 8
        ui->pushButton_5,  // 9
        ui->pushButton_6,  // 6
        ui->pushButton_7,  // 1
        ui->pushButton_8,  // 2
        ui->pushButton_9,  // 3
        ui->pushButton_11, // 0
        ui->pushButton_12  // .
    };
    for (auto *btn : digitButtons)
        connect(btn, &QPushButton::clicked, this, &MainWindow::digitPressed);

    // Connect operation buttons
    connect(ui->pushButton_14, &QPushButton::clicked, this, &MainWindow::operationPressed); // +
    connect(ui->pushButton_13, &QPushButton::clicked, this, &MainWindow::operationPressed); // -
    connect(ui->pushButton_15, &QPushButton::clicked, this, &MainWindow::operationPressed); // x
    connect(ui->pushButton_16, &QPushButton::clicked, this, &MainWindow::operationPressed); // /

    // Connect clear and equals
    connect(ui->pushButton_10, &QPushButton::clicked, this, &MainWindow::clearPressed);
    connect(ui->pushButton_17, &QPushButton::clicked, this, &MainWindow::equalsPressed);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::digitPressed() {
    QPushButton *btn = qobject_cast<QPushButton *>(sender());
    QString value = btn->text();

    if (waitingForOperand) {
        ui->lineEdit->clear();
        waitingForOperand = false;
    }

    ui->lineEdit->setText(ui->lineEdit->text() + value);
}

void MainWindow::operationPressed() {
    QPushButton *btn = qobject_cast<QPushButton *>(sender());
    pendingOperator = btn->text();
    storedValue = ui->lineEdit->text().toDouble();
    waitingForOperand = true;
}

void MainWindow::clearPressed() {
    ui->lineEdit->clear();
    storedValue = 0;
    pendingOperator.clear();
    waitingForOperand = false;
}

void MainWindow::equalsPressed() {
    double currentValue = ui->lineEdit->text().toDouble();
    double result = storedValue;

    if (pendingOperator == "+") result += currentValue;
    else if (pendingOperator == "-") result -= currentValue;
    else if (pendingOperator == "x") result *= currentValue;
    else if (pendingOperator == "/") result = (currentValue != 0) ? result / currentValue : 0;

    ui->lineEdit->setText(QString::number(result));
    waitingForOperand = true;
}

